
public class Railwaystation {
    int train;
    int toiletroom;
    boolean security;
    boolean bufet;
    Ticket ticket;
     public  Railwaystation (int train, int toiletroom, boolean security, boolean bufet){
         this.train=train;
         this.toiletroom=toiletroom;
         this.security=security;
         this.bufet=bufet;
     }
}
