

public class Rzd {
    public static void main(String[] args){
        Railwaystation railwaystation = new Railwaystation(6, 2,false, true);
        Ticket ticket = new Ticket(true, true, false);
        compare (railwaystation);
        compare1 (ticket);
    }
    private static void compare(Railwaystation railwaystation){

    }
    private  static void compare1 (Ticket ticket){

    }
}
